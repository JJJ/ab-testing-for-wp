// @flow @jsx wp.element.createElement

import './BoxShadow.css';

function BoxShadow() {
  return <div className="ab-test-for-wp__BoxShadow" />;
}

export default BoxShadow;
