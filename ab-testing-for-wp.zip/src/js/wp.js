const {
  i18n,
  blocks,
  editor,
  components,
  apiFetch,
  data,
  element,
} = wp;

export {
  i18n,
  blocks,
  editor,
  components,
  apiFetch,
  data,
  element,
};
