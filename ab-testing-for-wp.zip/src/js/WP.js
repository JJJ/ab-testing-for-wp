const {
  i18n,
  blocks,
  editor,
  components,
  apiFetch,
  data,
} = wp;

export {
  i18n,
  blocks,
  editor,
  components,
  apiFetch,
  data,
};
